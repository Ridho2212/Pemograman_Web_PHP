<?php 
class dosen extends CI_Controller{
    public function index()
    {
    $this -> load -> model('dosen_models','ds1');
    
    $this -> ds1 -> nidn = '08213';
    $this -> ds1 -> pendidikan ='S1';

    $this -> load -> model('dosen_models','ds2');
    
    $this -> ds2 -> nidn = '01010';
    $this -> ds2 -> pendidikan ='S2';

    $this -> load -> model('dosen_models','ds3');
    
    $this -> ds3 -> nidn = '01243';
    $this -> ds3 -> pendidikan ='S3';

    $list_dsn = [$this -> ds1, $this -> ds2, $this -> ds3];

    $data ['list_dsn'] = $list_dsn;

    $this -> load -> view('dosen/index', $data);
    }
}


?>