<?php 
class matakuliah extends CI_Controller{
    public function index()
    {
    $this -> load -> model('matakuliah_models', 'mt1');

    $this -> mt1 -> nama = 'Jaringan Komputer';
    $this -> mt1 -> sks = '3';
    $this -> mt1 -> kode = 'Jarkom';

    $this -> load -> model('matakuliah_models', 'mt2');

    $this -> mt2 -> nama = 'Basis Data';
    $this -> mt2 -> sks = '4';
    $this -> mt2 -> kode = 'BasDat';

    $list_mt = [$this->mt1, $this->mt2];
    
    $data['list_mt'] = $list_mt;

    $this -> load -> view('matakuliah/index', $data);
        
        
    }
}

?>