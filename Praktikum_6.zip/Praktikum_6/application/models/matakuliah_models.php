<?php 
class matakuliah_models extends CI_Model {
    public $nama;
    public $sks;
    public $kode;
}
?>