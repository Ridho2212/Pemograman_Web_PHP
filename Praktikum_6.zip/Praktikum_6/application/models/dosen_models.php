<?php 
class dosen_models extends CI_Model {
    public $nidn;
    public $pendidikan;
} 
?>